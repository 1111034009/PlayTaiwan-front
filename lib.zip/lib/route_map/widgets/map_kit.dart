import 'dart:math' as math;

import 'package:flutter/material.dart' hide Text;
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../../core/app_text_styles.dart';
import '../../core/app_notice.dart';
import '../theme.dart';

import 'package:playtaiwan/core/i18n.dart';
const _distance = Distance();

/// 舊地圖的羊皮紙色調：泛黃之外整體壓暗，白色變成米黃（約 #EDE0BF）。
/// 電子地圖底色接近白色，不壓暗的話太刺眼，深色路線和白色外框也不明顯
const _sepia = ColorFilter.matrix(<double>[
  0.56,
  0.30,
  0.07,
  0,
  0,
  0.16,
  0.66,
  0.06,
  0,
  0,
  0.12,
  0.22,
  0.41,
  0,
  0,
  0,
  0,
  0,
  1,
  0,
]);

const _nlscTiles =
    'https://wmts.nlsc.gov.tw/wmts/EMAP16/default/GoogleMapsCompatible/{z}/{y}/{x}';
const _osmTiles = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

/// 國土測繪中心的圖磚服務偶爾整個連不上（2026-11-02 就斷過）。伺服器沒回應時瀏覽器要等二十幾秒才逾時，
/// 整片地圖一直空白，所以第一次畫地圖時先試抓一塊圖磚，4 秒內抓不到，這次開 App 就改用 OpenStreetMap
final _nlscReachable = ValueNotifier<bool>(true);
bool _nlscChecked = false;

void _checkNlsc() {
  if (_nlscChecked) return;
  _nlscChecked = true;
  http
      .get(
        Uri.parse(
          'https://wmts.nlsc.gov.tw/wmts/EMAP16/default/GoogleMapsCompatible/7/55/107',
        ),
      )
      .timeout(const Duration(seconds: 4))
      .then((r) => _nlscReachable.value = r.statusCode == 200)
      .catchError((_) => _nlscReachable.value = false);
}

/// 藏寶圖底圖（國土測繪中心臺灣通用電子地圖 + 泛黃濾鏡；連不上時改用 OpenStreetMap）。
/// 用「無等高線及門牌」版（EMAP16）：只有路名和少數地標，不像 OpenStreetMap 滿是門牌號碼和店家圖示，劇本的印章比較顯眼。
/// 濾鏡整個圖層套一次，不要每一塊圖磚各包一層：畫面上幾十塊圖磚就多幾十層合成，地圖開久了手機會發燙
Widget treasureTiles() {
  _checkNlsc();
  return ValueListenableBuilder<bool>(
    valueListenable: _nlscReachable,
    builder: (context, nlsc, _) => ColorFiltered(
      colorFilter: _sepia,
      child: TileLayer(
        // 換圖源時整層重建，不沿用另一個圖源的圖磚
        key: ValueKey(nlsc),
        urlTemplate: nlsc ? _nlscTiles : _osmTiles,
        userAgentPackageName: 'tw.playtaiwan.play_taiwan_demo',
      ),
    ),
  );
}

/// 底圖來源標示（名稱沿用；跟著底圖換）
Widget osmAttribution() => ValueListenableBuilder<bool>(
  valueListenable: _nlscReachable,
  builder: (context, nlsc, _) => SimpleAttributionWidget(
    source: FlutterText(trs(nlsc ? '內政部國土測繪中心' : 'OpenStreetMap contributors')),
    backgroundColor: const Color(0xCCF3E4C1),
  ),
);

/// 預設的地圖互動：跟 Google 地圖一樣可以用兩指旋轉。
/// 旋轉時路線上的方向箭頭跟著路走；印章、徽章、周邊地點的標記用 rotate: true 保持正的
const mapInteraction = InteractionOptions(flags: InteractiveFlag.all);

/// 地圖轉過之後才出現的指北針（跟 Google 地圖一樣）：點一下轉回正北。
/// 要放在 FlutterMap 的 children 裡（要讀地圖現在的角度）
class NorthButton extends StatelessWidget {
  const NorthButton({
    super.key,
    required this.controller,
    this.alignment = Alignment.topRight,
    this.margin = const EdgeInsets.all(12),
  });

  final MapController controller;
  final Alignment alignment;
  final EdgeInsets margin;

  @override
  Widget build(BuildContext context) {
    final rotation = MapCamera.of(context).rotation;
    if (rotation.abs() < 0.5) return const SizedBox.shrink();

    return Align(
      alignment: alignment,
      child: Padding(
        padding: margin,
        child: Material(
          color: Pal.parchment,
          elevation: 3,
          shape: const CircleBorder(side: BorderSide(color: Pal.ink, width: 1.3)),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => controller.rotate(0),
            child: SizedBox(
              width: 40,
              height: 40,
              child: Transform.rotate(
                // 跟著地圖轉同樣的角度：箭頭一直指著地圖上的北方
                angle: rotation * math.pi / 180,
                child: const Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.navigation, size: 26, color: Pal.cinnabar),
                    Positioned(
                      top: 3,
                      child: Text(
                        'N',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          color: Pal.ink,
                          height: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// 我面向的方向（GPS 的行進方向，要在移動中才準）：藍色扇形，放在「我」的位置下面。
/// 不要設 rotate: true：要跟著地圖一起轉，指的才是真的方向
Marker headingMarker(LatLng point, double degrees) => Marker(
  point: point,
  width: 64,
  height: 64,
  child: IgnorePointer(
    child: Transform.rotate(
      angle: degrees * math.pi / 180,
      child: CustomPaint(painter: _HeadingPainter()),
    ),
  ),
);

class _HeadingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    // 往上（北）開的 70 度扇形，由圓心往外漸層變淡
    final rect = Rect.fromCircle(center: c, radius: r);
    final paint = Paint()
      ..shader = RadialGradient(
        colors: const [Color(0xAA2F80ED), Color(0x002F80ED)],
      ).createShader(rect);
    canvas.drawArc(rect, -math.pi / 2 - 0.61, 1.22, true, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// 手機上的底部面板：地圖用來知道面板現在蓋住地圖下方多高、把面板收起來。
/// 寬螢幕的面板在地圖右邊，不會蓋到地圖，[cover] 一律是 0
class MapPanelController extends ChangeNotifier {
  MapPanelController() {
    _sheet.addListener(notifyListeners);
  }

  final _sheet = DraggableScrollableController();
  double _height = 0;
  double _collapsed = 0;
  bool _side = false;

  /// 面板現在蓋住地圖下方多高（像素）
  double get cover {
    if (_side) return 0;
    return (_sheet.isAttached ? _sheet.size : _collapsed) * _height;
  }

  /// 面板收起來時蓋住多高（像素）
  double get collapsedCover => _side ? 0 : _collapsed * _height;

  /// 收到最低：只露出最上面的「下一步」，地圖整個看得到
  void collapse() {
    if (_side || !_sheet.isAttached) return;
    _sheet.animateTo(
      _collapsed,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _sheet.dispose();
    super.dispose();
  }
}

/// 寬螢幕（電腦、平板橫放）：左邊地圖、右邊面板；窄螢幕（手機）：地圖在上、面板從下方拉起。
/// 手機上的面板會卡在三個高度：收起（只露出面板最上面一小段，預設）、一半、全開，不會停在半路蓋住地圖
class MapWithPanel extends StatefulWidget {
  const MapWithPanel({
    super.key,
    required this.map,
    required this.panel,
    this.floating,
    this.floatingRight = false,
    this.controller,
  });

  final Widget map;
  final Widget Function(ScrollController? controller) panel;
  final MapPanelController? controller;

  /// 常駐在地圖角落的小東西（地圖上的 NPC），放在不擋畫面的地方：
  /// 寬螢幕在地圖右下角；手機在左下角、貼著面板的上緣跟著移動（右邊是交通方式的按鈕，會擠在一起）。
  /// 面板拉得很高時留在原地讓面板蓋過去
  final Widget? floating;

  /// 手機上也放在右下角（正式 App 的貓本來就在右下）
  final bool floatingRight;

  @override
  State<MapWithPanel> createState() => _MapWithPanelState();
}

class _MapWithPanelState extends State<MapWithPanel> {
  /// 手機上面板收起來時露出的高度（像素，不含下面被導覽列蓋住的部分）：剛好看得到面板最上面的「下一步」
  static const _collapsedVisible = 120.0;

  /// 面板現在佔螢幕高度的比例；還沒拉過是 null（收起來的高度）
  final _extent = ValueNotifier<double?>(null);

  @override
  void dispose() {
    _extent.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final map = widget.map, panel = widget.panel, floating = widget.floating;
    return LayoutBuilder(
      builder: (context, c) {
        if (c.maxWidth >= 900) {
          widget.controller?._side = true;
          return Row(
            children: [
              Expanded(
                child: floating == null
                    ? map
                    : Stack(
                        children: [
                          Positioned.fill(child: map),
                          // 下面讓出外面導覽列的高度（正式 App 的導覽列浮在頁面上面）
                          Positioned(
                            right: 12,
                            bottom: 30 + MediaQuery.paddingOf(context).bottom,
                            child: floating,
                          ),
                        ],
                      ),
              ),
              Container(
                width: 400,
                decoration: const BoxDecoration(
                  color: Pal.parchment,
                  border: Border(left: BorderSide(color: Pal.ink, width: 3)),
                ),
                // 有底色的 Container 會蓋掉 ListTile 的點擊水波，面板內容要再包一層 Material
                child: Material(
                  type: MaterialType.transparency,
                  child: panel(null),
                ),
              ),
            ],
          );
        }
        // 收起來：露出面板最上面一小段（下面被導覽列蓋住的部分另外加）；一半；全開
        final collapsed =
            ((MediaQuery.paddingOf(context).bottom + _collapsedVisible) /
                    c.maxHeight)
                .clamp(0.12, 0.4);
        const half = 0.5, full = 0.92;
        widget.controller
          ?.._side = false
          .._height = c.maxHeight
          .._collapsed = collapsed;
        return Stack(
          children: [
            Positioned.fill(child: map),
            if (floating != null)
              ValueListenableBuilder<double?>(
                valueListenable: _extent,
                builder: (context, extent, child) => Positioned(
                  left: widget.floatingRight ? null : 12,
                  right: widget.floatingRight ? 12 : null,
                  bottom: math.min(extent ?? collapsed, 0.6) * c.maxHeight + 10,
                  child: child!,
                ),
                child: floating,
              ),
            NotificationListener<DraggableScrollableNotification>(
              onNotification: (n) {
                _extent.value = n.extent;
                return false;
              },
              child: DraggableScrollableSheet(
                controller: widget.controller?._sheet,
                initialChildSize: collapsed,
                minChildSize: collapsed,
                maxChildSize: full,
                // 放手後卡到最近的一段，不會停在半路
                snap: true,
                snapSizes: [if (collapsed < half - 0.05) half],
                builder: (context, controller) => Container(
                  decoration: const BoxDecoration(
                    color: Pal.parchment,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(18),
                    ),
                    boxShadow: [
                      BoxShadow(color: Color(0x55000000), blurRadius: 12),
                    ],
                  ),
                  child: Material(
                    type: MaterialType.transparency,
                    child: panel(controller),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// 方位角（度，北 = 0、順時針）
double bearing(LatLng a, LatLng b) {
  final lat1 = a.latitudeInRad, lat2 = b.latitudeInRad;
  final dLon = (b.longitude - a.longitude) * math.pi / 180;
  final y = math.sin(dLon) * math.cos(lat2);
  final x =
      math.cos(lat1) * math.sin(lat2) -
      math.sin(lat1) * math.cos(lat2) * math.cos(dLon);
  return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
}

double lineLength(List<LatLng> pts) {
  double m = 0;
  for (var i = 1; i < pts.length; i++) {
    m += _distance.distance(pts[i - 1], pts[i]);
  }
  return m;
}

/// 折線上距起點 target 公尺的位置與行進方向
(LatLng, double) pointAlong(List<LatLng> pts, double target) {
  double walked = 0;
  for (var i = 1; i < pts.length; i++) {
    final seg = _distance.distance(pts[i - 1], pts[i]);
    if (seg > 0 && walked + seg >= target) {
      final t = (target - walked) / seg;
      final p = LatLng(
        pts[i - 1].latitude + (pts[i].latitude - pts[i - 1].latitude) * t,
        pts[i - 1].longitude + (pts[i].longitude - pts[i - 1].longitude) * t,
      );
      return (p, bearing(pts[i - 1], pts[i]));
    }
    walked += seg;
  }
  return (
    pts.last,
    pts.length >= 2 ? bearing(pts[pts.length - 2], pts.last) : 0,
  );
}

/// 沿線等距放方向箭頭。去程：實心箭頭；返程：空心箭頭。
List<Marker> arrowMarkers(
  List<LatLng> pts,
  Color color, {
  bool hollow = false,
  double spacing = 380,
}) {
  if (pts.length < 2) return const [];
  final length = lineLength(pts);
  if (length < 40) return const [];

  final count = (length / spacing).floor().clamp(1, 10);
  return List.generate(count, (i) {
    final (point, deg) = pointAlong(pts, length * (i + 0.5) / count);
    return Marker(
      point: point,
      width: 22,
      height: 22,
      child: IgnorePointer(
        child: ArrowIcon(color: color, hollow: hollow, degrees: deg),
      ),
    );
  });
}

class ArrowIcon extends StatelessWidget {
  const ArrowIcon({
    super.key,
    required this.color,
    required this.degrees,
    this.hollow = false,
    this.size = 20,
  });

  final Color color;
  final double degrees;
  final bool hollow;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: degrees * math.pi / 180,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Icon(
            Icons.navigation,
            size: size,
            color: hollow ? color : Colors.white,
          ),
          Icon(
            Icons.navigation,
            size: size * 0.62,
            color: hollow ? Colors.white : color,
          ),
        ],
      ),
    );
  }
}

/// 交通方式徽章（放在每一段路線中間）：圓形圖示，公車/捷運加上路線名
class ModeBadge extends StatelessWidget {
  const ModeBadge({
    super.key,
    required this.mode,
    required this.color,
    this.label,
    this.faded = false,
  });

  final String mode;
  final Color color;
  final String? label;
  final bool faded;

  @override
  Widget build(BuildContext context) {
    final style = modeStyle(mode, lineColor: color);
    return Opacity(
      opacity: faded ? 0.35 : 1,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: const [
                BoxShadow(color: Color(0x44000000), blurRadius: 3),
              ],
            ),
            child: Icon(style.icon, size: 15, color: Colors.white),
          ),
          if (label != null && label!.isNotEmpty)
            Flexible(
              child: Container(
                margin: const EdgeInsets.only(left: 2),
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: color, width: 1.5),
                ),
                child: Text(
                  label!,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: MapText.caption,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// 印章的樣子：一般；glow = 目前要去的景點，發亮；dark = 還沒解鎖的景點，暗的，在迷霧上只看得出位置
enum SealLook { normal, glow, dark }

/// 編號印章（劇本景點、起點、公車起訖站）
class SealMarker extends StatelessWidget {
  const SealMarker({
    super.key,
    required this.text,
    this.label,
    this.color = Pal.cinnabar,
    this.faded = false,
    this.look = SealLook.normal,
  });

  final String text;
  final String? label;
  final Color color;
  final bool faded;
  final SealLook look;

  @override
  Widget build(BuildContext context) {
    final dark = look == SealLook.dark;
    final glow = look == SealLook.glow;
    return Opacity(
      opacity: faded ? 0.4 : 1,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: dark ? const Color(0xFF4A3F35) : color,
              shape: BoxShape.circle,
              border: Border.all(
                color: dark ? const Color(0xFF8C7B66) : const Color(0xFFF7E7C4),
                width: 2,
              ),
              boxShadow: [
                if (glow)
                  const BoxShadow(
                    color: Color(0xF2FFD76A),
                    blurRadius: 24,
                    spreadRadius: 9,
                  ),
                const BoxShadow(
                  color: Color(0x66000000),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              text,
              style: TextStyle(
                color: dark ? const Color(0xFFB9AE98) : Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: MapText.bodySmall,
              ),
            ),
          ),
          if (label != null)
            Container(
              margin: const EdgeInsets.only(top: 2),
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: dark ? const Color(0xE62A1E14) : const Color(0xEEF3E4C1),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: dark
                      ? const Color(0xFF6B5A47)
                      : (glow ? Pal.cinnabar : Pal.inkSoft),
                  width: glow ? 1.6 : 0.8,
                ),
              ),
              child: Text(
                label!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: MapText.caption,
                  height: 1.2,
                  color: dark ? const Color(0xFFCDBF9F) : Pal.ink,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// 印章 Marker：圓心對準座標，名稱在下方；給 onTap 的話印章和名稱都可以點
Marker sealMarker(
  LatLng point,
  String text, {
  String? label,
  Color color = Pal.cinnabar,
  bool faded = false,
  SealLook look = SealLook.normal,
  VoidCallback? onTap,
}) => Marker(
  point: point,
  width: 130,
  height: 64,
  alignment: Alignment(0, 1 - 28 / 64),
  // 地圖旋轉時印章和名稱保持正的
  rotate: true,
  child: GestureDetector(
    onTap: onTap,
    child: SealMarker(
      text: text,
      label: label,
      color: color,
      faded: faded,
      look: look,
    ),
  ),
);

/// 路線中間點（依長度），放交通方式徽章用
LatLng midpoint(List<LatLng> pts) => pointAlong(pts, lineLength(pts) / 2).$1;

/// 鏡頭留白：寬螢幕避開左上角圖例；手機避開下方拉起的面板（[cover] 是面板蓋住的高度，沒給就當成約 42% 高），
/// 左右留地標名稱的寬度
EdgeInsets mapFitPadding(
  BuildContext context, {
  double base = 50,
  double? cover,
}) {
  final size = MediaQuery.sizeOf(context);
  if (size.width >= 900)
    return EdgeInsets.fromLTRB(base + 110, base, base, base);
  return EdgeInsets.fromLTRB(
    base * 0.9,
    base + 20,
    base * 0.9,
    (cover ?? size.height * 0.42) + base * 0.6,
  );
}

/// 把地圖鏡頭拉到能看到所有點
void fitTo(
  MapController controller,
  List<LatLng> points, {
  EdgeInsets padding = const EdgeInsets.all(60),
}) {
  if (points.isEmpty) return;
  if (points.length == 1) {
    controller.move(points.first, 16);
    return;
  }
  controller.fitCamera(
    CameraFit.coordinates(coordinates: points, padding: padding, maxZoom: 17),
  );
}

void showError(BuildContext context, Object e) {
  AppNotice.show('$e');
}
