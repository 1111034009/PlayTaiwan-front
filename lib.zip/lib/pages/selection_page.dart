import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../core/app_tutorial.dart';
import '../core/app_session.dart';
import '../core/app_colors.dart';
import '../core/app_text_styles.dart';
import '../core/taiwan_districts.dart';
import '../core/app_notice.dart';
import '../core/auth_guard.dart';
import '../core/story_generation.dart';
import '../block/navigationbar.dart';
import '../block/script_generating_overlay.dart';
import '../block/voice_idea_field.dart';

import '../api/story_api.dart';

import 'script_detail_page.dart';
import 'home_page.dart';
import 'play_idea_page.dart';
import 'travel_info_page.dart';
import 'pair_join_page.dart';

import 'package:playtaiwan/core/i18n.dart';
class SelectionPage extends StatefulWidget {
  const SelectionPage({super.key});

  @override
  State<SelectionPage> createState() => _SelectionPageState();
}

class _SelectionPageState extends State<SelectionPage> {
  static const Color pageColor = AppColors.background;
  static const Color red = AppColors.primaryAccent;

  static const double designWidth = 360;
  static const double designHeight = 658;

  int currentIndex = 0;

  bool isLoadingLocation = false;
  bool isGeneratingStory = false;
  double generatingProgress = 0.0;
  String generatingText = '正在整理旅程線索';
  Timer? _progressTimer;
  final GlobalKey _ideaKey = GlobalKey();
  final GlobalKey _locationKey = GlobalKey();
  final GlobalKey _randomKey = GlobalKey();
  final GlobalKey _teamKey = GlobalKey();
  String? selectedCity;
  String? selectedDistrict;
  final TextEditingController ideaController = TextEditingController();
  final GlobalKey<VoiceIdeaFieldState> _voiceKey =
      GlobalKey<VoiceIdeaFieldState>();

  static const Set<String> _validCities = {
    '臺北市',
    '新北市',
    '桃園市',
    '臺中市',
    '臺南市',
    '高雄市',
    '基隆市',
    '新竹市',
    '嘉義市',
    '新竹縣',
    '苗栗縣',
    '彰化縣',
    '南投縣',
    '雲林縣',
    '嘉義縣',
    '屏東縣',
    '宜蘭縣',
    '花蓮縣',
    '臺東縣',
    '澎湖縣',
    '金門縣',
    '連江縣',
  };

  static const int _maxIdeaLength = 100;

  String _normalizeCity(String city) {
    return city.trim().replaceAll('台', '臺');
  }

  bool _isValidCity(String city) {
    return _validCities.contains(_normalizeCity(city));
  }

  String? _validateIdea(String idea) {
    final String text = idea.trim();

    if (text.isEmpty) return '先說點什麼吧！';

    if (text.runes.length > _maxIdeaLength) {
      return '內容請在 $_maxIdeaLength 字以內';
    }

    if (RegExp(r'^[\s0-9０-９]+$').hasMatch(text)) {
      return '請輸入文字描述，不能只有數字';
    }

    if (!RegExp(r'\p{L}', unicode: true).hasMatch(text)) {
      return '請輸入文字描述，不能只有符號';
    }

    return null;
  }

  @override
  void initState() {
    super.initState();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: pageColor,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: pageColor,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeStartTutorial());
  }

  Future<void> _maybeStartTutorial() async {
    if (await AppTutorial.isDone(AppTutorial.selectionId)) return;

    await Future<void>.delayed(const Duration(milliseconds: 700));

    if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;

    AppTutorial.show(
      context,
      id: AppTutorial.selectionId,
      steps: [
        TutorialStep(target: _ideaKey, title: '遊你說了算', text: '直接說出你想要的旅行'),
        TutorialStep(target: _locationKey, title: '現在揪出發', text: '輸入地區，現在就出發'),
        TutorialStep(
          target: _randomKey,
          title: '來點遊意思',
          text: '轉轉盤，讓命運決定',
          align: ContentAlign.top,
        ),
        TutorialStep(target: _teamKey, title: '配對隊友劇本', text: '跟朋友一起玩'),
      ],
    );
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    ideaController.dispose();
    super.dispose();
  }

  Future<void> useCurrentLocation() async {
    if (isLoadingLocation) return;

    setState(() {
      isLoadingLocation = true;
    });

    try {
      final bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        _showLocationMessage('請先開啟手機的定位服務');
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();

        if (permission == LocationPermission.denied) {
          _showLocationMessage('需要定位權限才能取得目前位置');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _showLocationMessage('定位權限已被永久拒絕，請到手機設定開啟');
        return;
      }

      final Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      final String baseUrl = (dotenv.env['API_BASE_URL'] ?? '')
          .trim()
          .replaceFirst(RegExp(r'/$'), '');

      final String url = '$baseUrl/api/Map/Location';

      final String? token = AppSession.token;

      if (token == null || token.isEmpty) {
        _showLocationMessage('登入資訊已失效，請重新登入');
        return;
      }

      final response = await http.post(
        Uri.parse(url),
        headers: {
          'accept': 'text/plain',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'lat': position.latitude,
          'lng': position.longitude,
          'accuracy': 10,
        }),
      );

      if (response.statusCode >= 200 && response.statusCode < 400) {
        final Map<String, dynamic> data = jsonDecode(response.body);

        if (data['isSuccess'] == true) {
          final result = data['Result'];

          if (result is Map<String, dynamic>) {
            final String cityName =
                result['city_name']?.toString().trim() ?? '';

            final String districtName =
                result['district_name']?.toString().trim() ?? '';

            final String city = _normalizeCity(cityName);

            if (!taiwanDistricts.containsKey(city)) {
              _showLocationMessage('伺服器運行中，請稍後嘗試');
              return;
            }

            if (!mounted) return;

            setState(() {
              selectedCity = city;
              selectedDistrict = taiwanDistricts[city]!.contains(districtName)
                  ? districtName
                  : null;
            });

            return;
          }
        }
      }

      _showLocationMessage('定位錯誤，請稍後再試');
    } catch (e) {
      print('Location Error: $e');

      if (!mounted) return;

      _showLocationMessage('無法取得目前定位，請稍後再試');
    } finally {
      if (mounted) {
        setState(() {
          isLoadingLocation = false;
        });
      }
    }
  }

  void _showLocationMessage(String message) {
    if (!mounted) return;

    AppNotice.show(message);
  }

  /// 收鍵盤：unfocus + 直接叫系統輸入法隱藏（Android 偶爾只 unfocus 收不掉）
  void _hideKeyboard() {
    FocusManager.instance.primaryFocus?.unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  void startAdventure() {
    _hideKeyboard();

    final String? city = selectedCity;

    if (city == null || !_isValidCity(city)) {
      _showLocationMessage('請先選擇縣市');
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            TravelInfoPage(cityName: city, townName: selectedDistrict ?? ''),
      ),
    );
  }

  void randomAdventure() {
    _hideKeyboard();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PlayIdeaPage()),
    );
  }

  void joinTeam() {
    _hideKeyboard();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PairJoinPage()),
    );
  }

  Future<void> customAdventure() async {
    // 一按「開始」就先收鍵盤（放在最前面：已經在生成中、輸入有誤時也會收）
    _hideKeyboard();

    final StoryGeneration gen = StoryGeneration.instance;

    if (gen.active) {
      gen.showOverlay();
      return;
    }

    // 停掉錄音／播放
    // 還在錄但不到 5 秒：不能開始（錄音欄會提示），讓使用者繼續錄
    final bool voiceReady = await _voiceKey.currentState?.stopAll() ?? true;
    if (!voiceReady) return;

    // 有錄音：直接上傳錄音（語音版）；沒有錄音：用輸入欄的文字（文字版）。兩邊查進度、取消都是同一組
    final File? voice = _voiceKey.currentState?.recording;

    final String idea = ideaController.text.trim();

    if (voice == null) {
      final String? error = _validateIdea(idea);

      if (error != null) {
        _showLocationMessage(error);
        return;
      }
    }

    // 沒有真的進度：假的進度條 5 分鐘跑到 97%，做好了才快速跑到 100% 再跳轉
    final int run = gen.start(
      text: voice != null ? '紫薯編正在聽你說的話…' : '紫薯編尋找中…',
      cancelApi: StoryApi.cancelGenerateByText,
      fake: true,
    );

    try {
      void onJob(Map<String, dynamic> job) {
        if (!gen.isCurrent(run)) return;
        final int q = int.tryParse('${job['queue_position']}') ?? 0;
        final String stage = job['stage']?.toString().trim() ?? '';
        gen.setText(
          q > 0 ? '排隊中，前面還有 $q 個' : (stage.isNotEmpty ? stage : '紫薯編編寫中…'),
        );
      }

      final Map<String, dynamic> result = voice != null
          ? await StoryApi.generateByVoice(
              audio: voice,
              onJobId: gen.setJobId,
              onJob: onJob,
              onTranscript: (text) {
                if (!gen.isCurrent(run)) return;
                // 顯示「你說的是：……」，也填進輸入欄：辨識錯了可以取消後改字再送
                gen.setTranscript(text);
                _voiceKey.currentState?.showTranscript(text);
              },
            )
          : await StoryApi.generateByText(
              userPrompt: idea,
              onJobId: gen.setJobId,
              onJob: onJob,
            );

      if (!gen.isCurrent(run)) return;

      await gen.complete();

      if (!gen.isCurrent(run)) return;

      gen.finish();

      final dynamic data = result['data'];
      final dynamic intent = result['parsed_intent'];

      final String title = data is Map
          ? (data['title']?.toString().trim() ?? '')
          : '';

      final List<String> transportation =
          intent is Map && intent['transportation'] is List
          ? (intent['transportation'] as List).map((e) => e.toString()).toList()
          : const [];
      final int partySize = intent is Map
          ? (int.tryParse(intent['traveler_count']?.toString() ?? '') ?? 1)
          : 1;

      // 人可能已經離開這一頁（先回首頁了），所以用全域的 navigator 跳轉
      AuthGuard.navigatorKey.currentState?.push(
        MaterialPageRoute(
          builder: (context) => ScriptDetailPage(
            title: title.isEmpty ? '未命名劇本' : title,
            generatedScript: result,
            cityName: result['detected_city']?.toString() ?? '',
            townName: result['detected_town']?.toString() ?? '',
            transportation: transportation,
            partySize: partySize,
          ),
        ),
      );
    } catch (e) {
      if (e is StoryCancelled || gen.cancelled || !gen.isCurrent(run)) return;

      gen.finish();
      AppNotice.show(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  void goToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const HomePage()),
    );
  }

  // 360 x 630 的設計畫布內容
  Widget _buildDesignStack() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(child: Container(color: pageColor)),

        // 遊你說了算
        Positioned(
          top: 28,
          left: 0,
          right: 0,
          child: Center(
            child: SizedBox(
              width: 324,
              height: 190,
              child: _AdventurePaper(
                key: _ideaKey,
                child: _CustomAdventureContent(
                  ideaController: ideaController,
                  voiceKey: _voiceKey,
                  onPressed: customAdventure,
                ),
              ),
            ),
          ),
        ),

        // 隊友集結：放在畫布裡面（以前超出畫布上緣，那一塊點不到）
        Positioned(
          top: 6,
          right: 5,
          child: _JoinTeamBadge(key: _teamKey, onTap: joinTeam),
        ),

        // 現在揪出發
        Positioned(
          top: 228,
          left: 0,
          right: 0,
          child: Center(
            child: SizedBox(
              width: 324,
              height: 230,
              child: _AdventurePaper(
                key: _locationKey,
                child: _StartAdventureContent(
                  city: selectedCity,
                  district: selectedDistrict,
                  onCityChanged: (value) => setState(() {
                    selectedCity = value;
                    selectedDistrict = null;
                  }),
                  onDistrictChanged: (value) =>
                      setState(() => selectedDistrict = value),
                  onLocationPressed: useCurrentLocation,
                  onPressed: startAdventure,
                  loading: isLoadingLocation,
                ),
              ),
            ),
          ),
        ),

        // 來點遊意思
        Positioned(
          top: 468,
          left: 0,
          right: 0,
          child: Center(
            child: SizedBox(
              width: 324,
              height: 180,
              child: _AdventurePaper(
                key: _randomKey,
                child: _RandomAdventureContent(onPressed: randomAdventure),
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        PopScope(
          canPop: !StoryGeneration.instance.active,
          child: Scaffold(
            backgroundColor: pageColor,
            extendBody: false,
            resizeToAvoidBottomInset: false,
            body: SafeArea(
              bottom: false,
              child: LayoutBuilder(
              builder: (context, c) {
                // 直式手機以寬度為準縮放;橫向則以高度為準
                final bool portrait = c.maxHeight >= c.maxWidth;
                final double scale = portrait
                    ? c.maxWidth / designWidth
                    : c.maxHeight / designHeight;
                final double scaledWidth = designWidth * scale;
                final double scaledHeight = designHeight * scale;

                final Widget canvas = SizedBox(
                  width: scaledWidth,
                  height: scaledHeight,
                  child: FittedBox(
                    fit: BoxFit.contain,
                    alignment: Alignment.center,
                    child: SizedBox(
                      width: designWidth,
                      height: designHeight,
                      child: _buildDesignStack(),
                    ),
                  ),
                );

                // 高度夠:跟原本一樣置中顯示
                if (scaledHeight <= c.maxHeight + 0.5) {
                  return Center(child: canvas);
                }

                // 高度不夠:不縮小畫面,改成可上下滑動
                final EdgeInsets inset = MediaQuery.paddingOf(context);

                return SingleChildScrollView(
                  padding: EdgeInsets.only(bottom: inset.bottom + 8),
                  child: Center(child: canvas),
                );
              },
            ),
            ),
            bottomNavigationBar: AppNavigationBar(currentIndex: currentIndex),
          ),
        ),
      ],
    );
  }
}

class _AdventurePaper extends StatelessWidget {
  final Widget child;

  const _AdventurePaper({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(7),
        boxShadow: const [
          BoxShadow(
            color: Color(0x45000000),
            blurRadius: 6,
            offset: Offset(2, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset('img/set_papper.png', fit: BoxFit.fill),
            ),
            Positioned.fill(child: child),
          ],
        ),
      ),
    );
  }
}

class _StartAdventureContent extends StatelessWidget {
  final String? city;
  final String? district;
  final ValueChanged<String?> onCityChanged;
  final ValueChanged<String?> onDistrictChanged;
  final VoidCallback onLocationPressed;
  final VoidCallback onPressed;
  final bool loading;

  const _StartAdventureContent({
    required this.city,
    required this.district,
    required this.onCityChanged,
    required this.onDistrictChanged,
    required this.onLocationPressed,
    required this.onPressed,
    required this.loading,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 10, 22, 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Image.asset(
                'img/quill_pen.png',
                width: 30,
                height: 30,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  '現在揪出發',
                  textAlign: TextAlign.left,
                  maxLines: 1,
                  style: AppTextStyles.title.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '選擇指定的地區，現在揪出發',
            textAlign: TextAlign.left,
            maxLines: 1,
            style: AppTextStyles.bodySmallBold.copyWith(
              color: AppColors.mutedText,
            ),
          ),
          const SizedBox(height: 15),
          SizedBox(
            height: 36,
            child: Row(
              children: [
                Expanded(
                  child: _PaperDropdown(
                    hint: '縣市',
                    value: city,
                    items: taiwanDistricts.keys.toList(),
                    onChanged: onCityChanged,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _PaperDropdown(
                    hint: '行政區',
                    value: district,
                    emptyLabel: '不指定',
                    items: city == null ? const [] : taiwanDistricts[city!]!,
                    onChanged: onDistrictChanged,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: const Color(0xFF514A44),
          ),
          const SizedBox(height: 5),
          Align(
            alignment: Alignment.centerLeft,
            child: _LocationButton(onTap: onLocationPressed, loading: loading),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: _RedStartButton(text: '開始', onPressed: onPressed),
          ),
        ],
      ),
    );
  }
}

class _PaperDropdown extends StatelessWidget {
  final String hint;
  final String? value;
  final String? emptyLabel;
  final List<String> items;
  final ValueChanged<String?> onChanged;

  const _PaperDropdown({
    required this.hint,
    required this.value,
    required this.items,
    required this.onChanged,
    this.emptyLabel,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String?>(
        isExpanded: true,
        isDense: true,
        value: value,
        menuMaxHeight: 320,
        hint: Text(
          hint,
          maxLines: 1,
          style: AppTextStyles.bodyCompact.copyWith(color: AppColors.mutedText),
        ),
        icon: const Icon(Icons.arrow_drop_down, color: AppColors.textPrimary),
        style: AppTextStyles.bodyEmphasisBold.copyWith(
          color: AppColors.textPrimary,
        ),
        items: [
          if (emptyLabel != null)
            DropdownMenuItem<String?>(value: null, child: Text(emptyLabel!, maxLines: 1)),
          for (final item in items)
            DropdownMenuItem<String?>(value: item, child: Text(trArea(item), maxLines: 1)),
        ],
        onChanged: onChanged,
      ),
    );
  }
}

class _LocationButton extends StatefulWidget {
  final VoidCallback onTap;
  final bool loading;

  const _LocationButton({required this.onTap, required this.loading});

  @override
  State<_LocationButton> createState() => _LocationButtonState();
}

class _LocationButtonState extends State<_LocationButton> {
  bool hovering = false;
  bool pressing = false;

  @override
  Widget build(BuildContext context) {
    double scale = 1.0;

    if (hovering) {
      scale = 1.08;
    }

    if (pressing) {
      scale = 0.96;
    }

    return MouseRegion(
      onEnter: (_) {
        if (widget.loading) return;

        setState(() {
          hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.loading ? null : widget.onTap,
        onTapDown: widget.loading
            ? null
            : (_) {
                setState(() {
                  pressing = true;
                });
              },
        onTapUp: widget.loading
            ? null
            : (_) {
                setState(() {
                  pressing = false;
                });
              },
        onTapCancel: widget.loading
            ? null
            : () {
                setState(() {
                  pressing = false;
                });
              },
        child: AnimatedScale(
          scale: scale,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutBack,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.loading ? '正在定位...' : '使用當前定位',
                textAlign: TextAlign.left,
                style: AppTextStyles.bodyEmphasisBold.copyWith(
                  color: AppColors.primaryAccent,
                ),
              ),
              const SizedBox(width: 6),
              if (widget.loading)
                const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: AppColors.primaryAccent,
                  ),
                )
              else
                Image.asset(
                  'img/gps.png',
                  width: 35,
                  height: 25,
                  fit: BoxFit.contain,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RandomAdventureContent extends StatelessWidget {
  final VoidCallback onPressed;

  const _RandomAdventureContent({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 10, 22, 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Image.asset(
                'img/user_icon.png',
                width: 28,
                height: 28,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 7),
              Text(
                '來點遊意思',
                textAlign: TextAlign.left,
                style: AppTextStyles.title.copyWith(
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 13),
          Text(
            '轉動命運的轉盤，來點遊意思',
            textAlign: TextAlign.left,
            style: AppTextStyles.bodySmallBold.copyWith(
              color: AppColors.mutedText,
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: _RedStartButton(text: '開始', onPressed: onPressed),
          ),
        ],
      ),
    );
  }
}

class _CustomAdventureContent extends StatelessWidget {
  final TextEditingController ideaController;
  final GlobalKey<VoiceIdeaFieldState> voiceKey;
  final VoidCallback onPressed;

  const _CustomAdventureContent({
    required this.ideaController,
    required this.voiceKey,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 10, 22, 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Image.asset(
                'img/talk_play.png',
                width: 30,
                height: 30,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  '遊你說了算',
                  textAlign: TextAlign.left,
                  maxLines: 1,
                  style: AppTextStyles.title.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          Text(
            '你說出口的旅行，遊你說了算',
            textAlign: TextAlign.left,
            maxLines: 1,
            style: AppTextStyles.bodySmallBold.copyWith(
              color: AppColors.mutedText,
            ),
          ),
          const SizedBox(height: 10),
          // 可打字，也可語音輸入（辨識後能「聽一遍」確認，或點 ✕ 變回手動輸入）
          VoiceIdeaField(
            key: voiceKey,
            controller: ideaController,
            hintText: trs('例如:建議輸入人數與需求，預設為1人)'),
          ),
          const SizedBox(height: 10),
          // 錄音的按鈕在左邊、開始在右邊
          Row(
            children: [
              VoiceIdeaControls(fieldKey: voiceKey),
              const Spacer(),
              _RedStartButton(text: '開始', onPressed: onPressed),
            ],
          ),
        ],
      ),
    );
  }
}

class _RedStartButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;
  final double? width;

  const _RedStartButton({
    required this.text,
    required this.onPressed,
    this.width,
  });

  @override
  State<_RedStartButton> createState() => _RedStartButtonState();
}

class _RedStartButtonState extends State<_RedStartButton> {
  bool hovering = false;
  bool pressing = false;

  @override
  Widget build(BuildContext context) {
    double scale = 1.0;

    if (hovering) {
      scale = 1.07;
    }

    if (pressing) {
      scale = 0.96;
    }

    return MouseRegion(
      onEnter: (_) {
        setState(() {
          hovering = true;
        });
      },
      onExit: (_) {
        setState(() {
          hovering = false;
        });
      },
      child: GestureDetector(
        onTap: widget.onPressed,
        onTapDown: (_) {
          setState(() {
            pressing = true;
          });
        },
        onTapUp: (_) {
          setState(() {
            pressing = false;
          });
        },
        onTapCancel: () {
          setState(() {
            pressing = false;
          });
        },
        child: AnimatedScale(
          scale: scale,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutBack,
          child: Container(
            width: widget.width ?? 70,
            height: 43,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppColors.primaryLight, AppColors.primary],
              ),
              border: Border.all(color: AppColors.primaryDark, width: 2),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x70000000),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              widget.text,
              textAlign: TextAlign.center,
              style: AppTextStyles.button.copyWith(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

class _JoinTeamBadge extends StatefulWidget {
  final VoidCallback onTap;

  const _JoinTeamBadge({super.key, required this.onTap});
  @override
  State<_JoinTeamBadge> createState() => _JoinTeamBadgeState();
}

class _JoinTeamBadgeState extends State<_JoinTeamBadge> {
  bool pressing = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => pressing = true),
      onTapUp: (_) => setState(() => pressing = false),
      onTapCancel: () => setState(() => pressing = false),
      child: AnimatedScale(
        scale: pressing ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOutBack,
        child: Transform.rotate(
          angle: 0.05,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primaryDark, width: 2),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppColors.primaryLight, AppColors.primary],
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x70000000),
                  blurRadius: 5,
                  offset: Offset(1, 3),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.groups_rounded, size: 18, color: Colors.white),
                const SizedBox(width: 6),
                Text(
                  '配對隊友劇本',
                  style: AppTextStyles.captionBold.copyWith(
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
